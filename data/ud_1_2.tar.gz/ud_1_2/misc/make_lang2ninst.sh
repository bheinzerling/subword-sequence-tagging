#! /usr/bin/env bash
set -euo pipefail

traindir=../../data/babeltag/ud_1_2/train
langs=$(ls $traindir | cut -f1 -d'.')

echo "{"
for lang in $langs; do
	ninst=$(grep -v "." $traindir/${lang}.conllu | wc -l)
	echo \"${lang}\": $ninst,
done
echo "}"
